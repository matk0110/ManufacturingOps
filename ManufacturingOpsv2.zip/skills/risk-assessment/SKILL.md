---
name: risk-assessment
description: |
  Conducts manufacturing risk assessments and triage across safety, quality, supplier, production, and delivery dimensions.
  Use when user asks to "assess risk", "risk assessment", "risk triage", "risk matrix",
  "FMEA", "risk analysis", "identify risks", "supplier risk", "safety risk", or "production risk".
license: MIT
metadata:
  author: Microsoft Manufacturing SE
  version: "1.0"
---

# Risk Assessment & Triage

## What This Skill Does

Guides Cowork through a structured manufacturing risk assessment using a 5×5 severity/likelihood matrix across five key risk domains, with optional FMEA integration.

## Data Sources

Search ONLY the **Contoso Motors** SharePoint document library for existing risk data. Do NOT search emails, Teams messages, or calendar.
- **SharePoint location**: `https://m365x38311559.sharepoint.com/sites/ContosoMotors/Shared Documents/Manufacturing Ops`
- Search for files matching: risk assessment, risk register, FMEA, risk matrix
- Use existing risk assessments and production data to inform the analysis

## Workflow

1. Search the Manufacturing Ops SharePoint library for existing risk assessments and production reports with equipment/downtime trend data
2. Ask the user for scope: which risk categories to assess, which lines/products/suppliers to evaluate
2. For each risk category, identify specific hazards or failure modes
3. Score each risk using the 5×5 severity × likelihood matrix
4. Prioritize risks by Risk Priority Number (RPN) or matrix score
5. Recommend mitigation actions for high and critical risks
6. Generate the risk register with owners and target dates

## Risk Categories

### Safety Risks
- Ergonomic hazards (repetitive motion, heavy lifting, awkward posture)
- Chemical exposure (HazCom/GHS, SDS compliance)
- Machine guarding (pinch points, rotating parts, nip points)
- Fall protection (elevated work, ladders, platforms)
- Electrical safety (arc flash, LOTO compliance)
- Thermal hazards (hot surfaces, molten materials, steam)

### Quality Risks
- Process capability drift (Cpk trending below 1.33)
- Measurement system variation (Gage R&R exceeding 10%)
- Incoming material quality trends (supplier PPM increasing)
- First Pass Yield declining
- Customer complaint rate increasing

### Supplier Risks
- Single-source dependency (no alternate supplier qualified)
- Lead time variability (standard deviation of delivery days)
- Financial health of critical suppliers
- Quality history (PPM trend, number of SCARs)
- Geopolitical/logistics exposure

### Production Risks
- Equipment age and reliability (MTBF trend declining)
- Skill concentration (single operator for critical operations)
- Capacity utilization stress (>90% sustained utilization)
- Changeover frequency and duration
- WIP level volatility

### Delivery Risks
- Schedule adherence trend (% of on-time deliveries)
- Finished goods inventory coverage (days of supply)
- Transportation and logistics disruptions
- Customer order volatility (demand variability coefficient)

## Risk Scoring Matrix (5×5)

### Severity Scale

| Score | Severity | Description |
|-------|----------|-------------|
| 5 | Catastrophic | Fatality, plant shutdown, product recall, major regulatory action |
| 4 | Major | Serious injury, line shutdown >24hr, customer reject, audit finding |
| 3 | Moderate | Medical treatment, line down 4-24hr, internal reject, customer complaint |
| 2 | Minor | First aid, line down <4hr, rework required, minor deviation |
| 1 | Negligible | No injury, no production impact, cosmetic defect, process adjustment |

### Likelihood Scale

| Score | Likelihood | Description |
|-------|------------|-------------|
| 5 | Almost Certain | Expected to occur weekly or more frequently |
| 4 | Likely | Expected to occur monthly |
| 3 | Possible | Could occur quarterly |
| 2 | Unlikely | May occur annually |
| 1 | Rare | May occur over multiple years |

### Risk Matrix

|  | Sev 1 | Sev 2 | Sev 3 | Sev 4 | Sev 5 |
|--|-------|-------|-------|-------|-------|
| **Like 5** | 5 🟡 | 10 🟡 | 15 🟠 | 20 🔴 | 25 🔴 |
| **Like 4** | 4 🟢 | 8 🟡 | 12 🟡 | 16 🟠 | 20 🔴 |
| **Like 3** | 3 🟢 | 6 🟡 | 9 🟡 | 12 🟡 | 15 🟠 |
| **Like 2** | 2 🟢 | 4 🟢 | 6 🟡 | 8 🟡 | 10 🟡 |
| **Like 1** | 1 🟢 | 2 🟢 | 3 🟢 | 4 🟢 | 5 🟡 |

### Response by Risk Level

| Score Range | Level | Required Response |
|-------------|-------|-------------------|
| 20–25 🔴 | **Critical** | Immediate action required, escalate to plant manager |
| 15–19 🟠 | **High** | Action plan within 24 hours, assign owner |
| 8–14 🟡 | **Medium** | Monitor weekly, include in management review |
| 1–7 🟢 | **Low** | Accept and monitor quarterly |

## Risk Register Output

| # | Category | Risk Description | Severity | Likelihood | Score | Level | Mitigation | Owner | Target Date | Status |
|---|----------|-----------------|----------|------------|-------|-------|------------|-------|-------------|--------|

## FMEA Integration (Optional)

When applicable, extend the risk register to Process FMEA format:

| Failure Mode | Effect | Severity | Cause | Occurrence | Current Controls | Detection | RPN | Recommended Action |
|-------------|--------|----------|-------|------------|-----------------|-----------|-----|-------------------|

**RPN** = Severity × Occurrence × Detection (scale 1-10 each, max 1000)
- RPN > 200: Immediate corrective action required
- RPN 100-200: Action plan needed
- RPN < 100: Monitor
