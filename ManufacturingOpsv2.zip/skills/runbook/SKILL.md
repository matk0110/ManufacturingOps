---
name: runbook
description: |
  Creates shift handoff runbooks, line-down response procedures, and quality hold process guides for manufacturing operations.
  Use when user asks for "shift handoff", "handoff runbook", "line down response", "line-down procedure",
  "quality hold", "shift change", "shift transition", or "what to hand off to next shift".
license: MIT
metadata:
  author: Microsoft Manufacturing SE
  version: "1.0"
---

# Shift Handoff & Operational Runbooks

## What This Skill Does

Guides Cowork through creating structured operational runbooks for the three most critical manufacturing handoff scenarios: shift transitions, line-down emergencies, and quality holds.

## Data Sources

Search ONLY the **Contoso Motors** SharePoint document library for current operational data. Do NOT search emails, Teams messages, or calendar.
- **SharePoint location**: `https://m365x38311559.sharepoint.com/sites/ContosoMotors/Shared Documents/Manufacturing Ops`
- Search for files matching: shift handoff, shift transition, quality hold, line down
- Use the data from these documents to pre-populate the runbook with current status

## Workflow

1. Search the Manufacturing Ops SharePoint library for the latest shift handoff documents, production reports, and quality hold records
2. Ask the user which runbook type they need:
   - **Shift Handoff** — end-of-shift status and incoming shift priorities
   - **Line-Down Response** — tiered escalation for unplanned stoppages
   - **Quality Hold** — containment, investigation, and disposition process
2. Collect context: plant/line, shift, current production status, active issues
3. Generate the runbook with checklists, escalation tiers, and owner assignments

## Shift Handoff Runbook

### Production Status

| Line/Cell | Target | Actual | Rate (UPH) | Schedule Adherence % | Notes |
|-----------|--------|--------|-------------|----------------------|-------|

### Open Issues

| # | Issue | Type | Line | Priority | Owner | Status |
|---|-------|------|------|----------|-------|--------|
| | | Equipment/Quality/Material/Safety | | P1-P4 | | Open/In Progress |

### Active Safety Items
- [ ] Lockout/Tagout (LOTO) active: [location]
- [ ] Confined space permits: [location]
- [ ] Hot work permits: [location]
- [ ] Spill/chemical alerts: [details]

### Material Status
- Shortages: [list parts/materials at risk]
- Incoming deliveries: [expected arrivals this shift]
- Staging status: [next job materials staged Y/N]

### Carry-Over Actions

| # | Action | Owner | Expected Completion | Priority |
|---|--------|-------|---------------------|----------|

### Incoming Shift Top 3 Priorities
1. [Highest impact action]
2. [Second priority]
3. [Third priority]

---

## Line-Down Response Runbook

### Immediate Actions (First 5 Minutes)
1. ✅ Verify personnel safety — no one in danger
2. ✅ Notify shift supervisor
3. ✅ Start downtime clock in MES/tracking system
4. ✅ Initial troubleshooting (operator-level, 5 min max)

### Escalation Tiers

| Tier | Role | Time Window | Actions |
|------|------|-------------|---------|
| **Tier 1** | Operator | 0–5 min | Basic troubleshooting, reset, visual inspection |
| **Tier 2** | Maintenance Tech | 5–15 min | Diagnostic, component swap, calibration |
| **Tier 3** | Engineering | 15–30 min | Root cause analysis, design/process change |
| **Tier 4** | Management + Vendor | 30+ min | Vendor support call, production reschedule, customer notification |

### Communication Protocol
At each tier escalation, notify with:
- Line/cell affected
- Symptom description
- Duration so far
- Impact (units lost, customer orders at risk)

### Recovery Checklist
- [ ] Equipment restart procedure completed
- [ ] First-piece inspection passed
- [ ] Quality re-verification completed
- [ ] Downtime event logged with root cause code
- [ ] Production rate confirmed at standard

---

## Quality Hold Process

### Hold Initiation
1. Isolate suspect lot/batch — physically segregate with hold tags
2. Enter hold in MES/ERP system with lot/batch numbers
3. Notify Quality Engineer and Supervisor
4. Document: what, when, where, how much, who found it

### Investigation (8D/5-Why)
- **Containment**: Prevent suspect material from shipping
- **Root Cause**: Use 5-Why or fishbone (Ishikawa) analysis
- **Scope**: Determine full extent — check upstream/downstream lots

### Disposition

| Disposition | Criteria | Approval Required |
|-------------|----------|-------------------|
| **Use As-Is** | Within tolerance, no functional impact | Quality Engineer |
| **Rework** | Can be brought to spec | Quality Engineer + Supervisor |
| **Scrap** | Cannot be salvaged | Quality Manager |
| **Return to Vendor** | Incoming material defect | Quality + Purchasing |

### Release Criteria
- [ ] Root cause identified and documented
- [ ] Quality Engineer sign-off
- [ ] Re-inspection results within spec
- [ ] Customer notification completed (if required by contract)
- [ ] CAPA initiated (if systemic issue)
