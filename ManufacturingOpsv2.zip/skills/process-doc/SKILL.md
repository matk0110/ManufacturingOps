---
name: process-doc
description: |
  Creates manufacturing process documentation including SOPs, standard work sheets, work instructions, and escalation paths.
  Use when user asks to "write an SOP", "create work instructions", "standard operating procedure",
  "standard work", "process documentation", "escalation path", or "document this process".
license: MIT
metadata:
  author: Microsoft Manufacturing SE
  version: "1.0"
---

# Process Documentation

## What This Skill Does

Guides Cowork through creating structured manufacturing process documents following ISO 9001 document control requirements and lean manufacturing standard work principles.

## Data Sources

Search ONLY the **Contoso Motors** SharePoint document library for existing process documentation. Do NOT search emails, Teams messages, or calendar.
- **SharePoint location**: `https://m365x38311559.sharepoint.com/sites/ContosoMotors/Shared Documents/Manufacturing Ops`
- Search for files matching: SOP, standard operating procedure, work instruction, changeover
- Use existing documents as templates or reference for formatting and content

## Workflow

1. Search the Manufacturing Ops SharePoint library for existing SOPs or work instructions that can be used as a template or updated
2. Ask the user which document type they need:
   - **SOP** (Standard Operating Procedure) — formal procedure with approvals
   - **Standard Work** — lean manufacturing operator work sequence
   - **Work Instructions** — step-by-step visual-friendly task guide
   - **Escalation Path** — decision tree for non-conformance response
2. Collect process details: operation name, work center/line, applicable product(s), current revision status
3. Generate the document in the appropriate format
4. Include safety warnings, quality checkpoints, and regulatory references as applicable

## Document Templates

### SOP Format

| Field | Value |
|-------|-------|
| **Document ID** | SOP-[Dept]-[###] |
| **Title** | [Process Name] |
| **Revision** | [Rev #] |
| **Effective Date** | [Date] |
| **Owner** | [Name/Role] |
| **Approved By** | [Name/Role] |

**Sections:**
1. **Purpose** — Why this procedure exists
2. **Scope** — What operations/products/lines it covers
3. **Responsibilities** — Roles and their duties
4. **PPE Requirements** — Required personal protective equipment
5. **Materials & Equipment** — Tools, gauges, consumables needed
6. **Procedure** — Numbered steps with CTQ callouts
7. **Quality Checkpoints** — Inspection points with go/no-go criteria
8. **Safety & Environmental** — Hazards, OSHA references, waste handling
9. **Escalation** — Who to contact for issues at each severity
10. **Revision History** — Date, revision #, change description, author

### Standard Work Format

| Element | Value |
|---------|-------|
| **Takt Time** | [seconds] |
| **Cycle Time** | [seconds] |
| **Standard WIP** | [units] |
| **Work Sequence** | Numbered steps with time per step |

Include an operator balance chart showing time per step vs. takt time.

### Work Instruction Step Format

| Step # | Action | Image/Diagram | CTQ? | Go/No-Go Criteria |
|--------|--------|---------------|------|--------------------|
| 1      | [verb + object] | [reference] | ✅/— | [acceptance criteria] |

⚠️ Mark safety-critical steps with warnings.

### Escalation Path

| Severity | Condition | Action | Contact | Response Time |
|----------|-----------|--------|---------|---------------|
| Level 1 | Minor deviation | Operator adjusts | Team Lead | Immediate |
| Level 2 | Out of spec | Stop and notify | Supervisor | 15 min |
| Level 3 | Repeated failure | Line hold | Quality Engineer | 30 min |
| Level 4 | Safety/regulatory | Emergency stop | Plant Manager + EHS | Immediate |

## Compliance Notes
- Follow ISO 9001 Clause 7.5 for document control (ID, revision, approval, distribution)
- Reference OSHA standards by number for safety procedures (e.g., 29 CFR 1910.147 for LOTO)
- Include revision history for audit traceability
