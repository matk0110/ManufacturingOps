---
name: change-request
description: |
  Drafts engineering change requests (ECRs) for engineering changes, tooling changes, process changes, and line changeover approvals in manufacturing.
  Use when user asks to "create a change request", "engineering change", "ECR", "ECN",
  "tooling change", "process change", "line changeover", "change approval", or "change management".
license: MIT
metadata:
  author: Microsoft Manufacturing SE
  version: "1.0"
---

# Engineering & Process Change Management

## What This Skill Does

Guides Cowork through drafting manufacturing change requests with proper impact assessment, approval routing, and validation requirements for engineering, tooling, process, and line changeover changes.

## Data Sources

Search ONLY the **Contoso Motors** SharePoint document library for related change documentation. Do NOT search emails, Teams messages, or calendar.
- **SharePoint location**: `https://m365x38311559.sharepoint.com/sites/ContosoMotors/Shared Documents/Manufacturing Ops`
- Search for files matching: ECR, engineering change, change request, tooling change
- Use existing ECRs as reference for formatting and approval workflows

## Workflow

1. Search the Manufacturing Ops SharePoint library for existing ECRs and related documentation
2. Ask the user for the change type:
   - **Engineering Change** — design or BOM modification
   - **Tooling Change** — new or modified tooling/fixtures
   - **Process Change** — routing, parameters, or method change
   - **Line Changeover** — product mix change on a production line
2. Collect change details: description, reason, affected parts/lines
3. Generate the impact assessment
4. Determine the approval matrix based on change severity
5. Define validation requirements and implementation plan

## Engineering Change Request (ECR) Template

### Header

| Field | Value |
|-------|-------|
| **ECR Number** | ECR-[YYYY]-[###] |
| **Date Initiated** | [Date] |
| **Initiated By** | [Name/Role] |
| **Change Type** | Engineering / Tooling / Process / Line Changeover |
| **Priority** | Urgent / High / Normal / Low |

### Change Description
- **Current State**: [What exists today]
- **Proposed Change**: [What will change]
- **Reason Code**: Cost Reduction / Quality Improvement / Customer Requirement / Safety / Regulatory

### Affected Items

| Part Number | Description | Current Rev | New Rev | BOM Impact |
|-------------|-------------|-------------|---------|------------|

### Affected Work Centers

| Work Center | Line | Operation # | Impact Description |
|-------------|------|-------------|-------------------|

### Impact Assessment

| Category | Impact | Severity (H/M/L) | Mitigation |
|----------|--------|-------------------|------------|
| **Quality** | [risk to product quality] | | |
| **Production** | [downtime, throughput impact] | | |
| **Tooling** | [new/modified tooling cost] | | |
| **Training** | [operator retraining needed] | | |
| **Inventory** | [obsolete stock, scrap exposure] | | |
| **Customer** | [notification, re-qualification] | | |
| **Regulatory** | [re-certification needed] | | |

### Approval Matrix

| Change Severity | Required Approvers |
|-----------------|-------------------|
| **Minor** (no form/fit/function impact) | Quality Engineer + Production Supervisor |
| **Major** (affects form/fit/function) | Plant Manager + Quality Manager + Engineering Manager |
| **Safety/Regulatory** | All above + EHS Manager + Compliance Officer |
| **Customer-Affecting** | All above + Customer Quality contact (PPAP resubmission) |

### Approval Sign-Off

| Role | Name | Approve/Reject | Date | Comments |
|------|------|----------------|------|----------|

### Validation Requirements
- [ ] First Article Inspection (FAI) — per AS9102 or customer standard
- [ ] Process Capability Study — target Cpk ≥ 1.33 (Ppk for initial)
- [ ] Measurement System Analysis (MSA) — Gage R&R < 10%
- [ ] Customer PPAP submission (if customer-affecting)
- [ ] Control Plan updated
- [ ] FMEA updated

### Implementation Plan

| # | Task | Owner | Target Date | Status |
|---|------|-------|-------------|--------|
| 1 | Prototype/pilot run | | | |
| 2 | FAI completion | | | |
| 3 | Training delivered | | | |
| 4 | Production effective date | | | |
| 5 | Lot/serial breakpoint | | | |

---

## Line Changeover Approval Checklist

### Pre-Changeover
- [ ] Materials for next product staged and verified
- [ ] Tooling/fixtures for next product inspected and ready
- [ ] Quality standards and visual aids posted for next product
- [ ] Operators briefed on next product requirements
- [ ] Changeover target time set: [target min] (SMED goal)

### Changeover Execution
- Track actual changeover time vs. target
- Apply SMED principles: separate internal vs. external setup

### Post-Changeover Verification
- [ ] First-piece inspection — dimensional check passed
- [ ] Visual inspection — cosmetic/surface requirements met
- [ ] Process parameters verified against control plan
- [ ] Line running at standard rate
- [ ] Changeover time logged: actual [min] vs. target [min]
