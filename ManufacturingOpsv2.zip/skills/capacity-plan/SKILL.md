---
name: capacity-plan
description: |
  Performs capacity planning analysis including constraint identification, line/load balancing, and labor/machine bottleneck review.
  Use when user asks to "analyze capacity", "capacity plan", "line load analysis", "bottleneck review",
  "labor analysis", "machine utilization", "capacity constraints", or "can we meet demand".
license: MIT
metadata:
  author: Microsoft Manufacturing SE
  version: "1.0"
---

# Capacity Planning & Constraint Analysis

## What This Skill Does

Guides Cowork through a structured capacity analysis using Theory of Constraints (TOC) principles to identify bottlenecks, evaluate line/load balance, and recommend corrective actions.

## Data Sources

Search ONLY the **Contoso Motors** SharePoint document library for existing capacity data. Do NOT search emails, Teams messages, or calendar.
- **SharePoint location**: `https://m365x38311559.sharepoint.com/sites/ContosoMotors/Shared Documents/Manufacturing Ops`
- Search for files matching: capacity plan, line load analysis, bottleneck
- Use the data from these documents to inform the capacity analysis

## Workflow

1. Search the Manufacturing Ops SharePoint library for existing capacity plans and production output data
2. Ask the user for: product family, planning horizon (week/month/quarter), available lines/work centers, and customer demand (units or takt time)
2. Calculate available capacity per line/work center:
   - Available Time = (Shifts × Hours/Shift × Working Days) − Planned Downtime
   - Demonstrated Capacity = Available Time / Cycle Time per unit
3. Compare demand vs. capacity to identify constraint resources
4. Analyze labor: headcount vs. standard, skill matrix gaps, overtime requirements
5. Analyze equipment: scheduled vs. available hours, changeover impact, maintenance windows
6. Generate recommendations prioritized by impact and feasibility

## Output Format

### Demand vs. Capacity Summary

| Work Center | Takt Time (sec) | Cycle Time (sec) | Available Hrs/Week | Capacity (units/wk) | Demand (units/wk) | Utilization % | Status |
|-------------|-----------------|-------------------|--------------------|----------------------|--------------------|---------------|--------|
| [Name]      | [val]           | [val]             | [val]              | [val]                | [val]              | [%]           | 🟢/🟡/🔴 |

**Status Thresholds:**
- 🟢 Green: <80% utilization (headroom available)
- 🟡 Amber: 80-95% utilization (near capacity)
- 🔴 Red: >95% utilization (bottleneck / over-capacity)

### Bottleneck Identification

Identify the constraint resource (highest utilization) and calculate:
- Constraint utilization %
- Impact of constraint on total throughput
- Buffer time before/after constraint (drum-buffer-rope)

### Labor Analysis

| Role/Skill | Required HC | Available HC | Gap | Overtime Hrs Needed | Notes |
|------------|-------------|--------------|-----|---------------------|-------|

### Machine Utilization

| Equipment | Scheduled Hrs | Available Hrs | Planned Maint | Changeover Hrs | Net Available | Utilization % |
|-----------|---------------|---------------|----------------|----------------|---------------|---------------|

### Recommendations

| # | Action | Type | Impact | Effort | Timeline |
|---|--------|------|--------|--------|----------|

**Action types:** Rebalance, Overtime, Shift Add, Subcontract, Capital Investment, Changeover Reduction (SMED)

## Key Formulas
- **Takt Time** = Available Production Time / Customer Demand
- **OEE** = Availability × Performance × Quality
- **Utilization** = (Actual Output / Maximum Possible Output) × 100
- **Throughput** = limited by the constraint (bottleneck) resource
