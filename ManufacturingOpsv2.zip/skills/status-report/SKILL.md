---
name: status-report
description: |
  Generates daily production status reports, plant leadership reports, and shift summaries for manufacturing operations.
  Use when user asks to "create a production report", "daily status update", "shift summary",
  "plant leadership report", "production review", "how did the shift go", or "end of day report".
license: MIT
metadata:
  author: Microsoft Manufacturing SE
  version: "1.0"
---

# Daily Production Status Report

## What This Skill Does

Guides Cowork through creating a comprehensive daily production status report suitable for plant leadership stand-up meetings, shift handoffs, and management reviews.

## Data Sources

Search ONLY the **Contoso Motors** SharePoint document library for existing production data. Do NOT search emails, Teams messages, or calendar.
- **SharePoint location**: `https://m365x38311559.sharepoint.com/sites/ContosoMotors/Shared Documents/Manufacturing Ops`
- Search for files matching: daily production report, shift summary, production status
- Use the data from these documents to populate the report with real metrics

## Workflow

1. Search the Manufacturing Ops SharePoint library for the most recent production report or shift summary
2. Ask the user for context: plant/facility name, shift (1st/2nd/3rd), date, and product lines running
3. Collect or prompt for the following data points per production line:
   - Planned vs. actual output (units)
   - OEE (Overall Equipment Effectiveness) or its components: Availability × Performance × Quality
   - Downtime events (planned and unplanned) with duration and root cause
3. Compile quality metrics: First Pass Yield (FPY), scrap rate, rework count, DPMO if available
4. Capture safety data: incidents, near-misses, behavioral observations, days since last recordable
5. List carry-over actions and priorities for the next shift
6. Generate the formatted report with RAG status indicators

## Output Format

Present the report in this structure:

### Header
- **Plant/Facility**: [Name]
- **Date**: [Date] | **Shift**: [1st/2nd/3rd]
- **Report prepared by**: [Name/Role]

### Production Summary

| Line/Cell | Planned | Actual | Variance | OEE | RAG Status |
|-----------|---------|--------|----------|-----|------------|
| Line 1    | [val]   | [val]  | [+/-%]   | [%] | 🟢/🟡/🔴  |

**RAG Thresholds:**
- 🟢 Green: ≥95% of target
- 🟡 Amber: 85-94% of target
- 🔴 Red: <85% of target

### Downtime Pareto (Top 3)

| Rank | Event | Line | Duration (min) | Category | Root Cause |
|------|-------|------|----------------|----------|------------|

### Quality Metrics

| Metric | Target | Actual | RAG |
|--------|--------|--------|-----|
| First Pass Yield | [%] | [%] | |
| Scrap Rate | [%] | [%] | |
| Rework Count | [#] | [#] | |

### Safety
- Recordable incidents: [#]
- Near-misses: [#]
- Days since last recordable: [#]

### Key Actions & Carry-Over

| # | Action | Owner | Due | Priority |
|---|--------|-------|-----|----------|

## Key Manufacturing Terms
- **OEE**: Availability × Performance × Quality (world-class = 85%+)
- **FPY**: Units passing inspection on first attempt / total units
- **DPMO**: Defects per million opportunities
- **Pareto**: Ranking by frequency/impact (80/20 rule)
