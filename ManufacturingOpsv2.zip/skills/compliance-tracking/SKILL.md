---
name: compliance-tracking
description: |
  Tracks regulatory compliance and prepares for audits across OSHA, ISO 9001, IATF 16949, FDA, and GMP standards in manufacturing.
  Use when user asks to "audit prep", "compliance check", "compliance tracking", "audit readiness",
  "ISO audit", "OSHA compliance", "IATF 16949", "FDA audit", "GMP review", "customer audit",
  "regulatory compliance", or "gap analysis".
license: MIT
metadata:
  author: Microsoft Manufacturing SE
  version: "1.0"
---

# Regulatory Compliance & Audit Preparation

## What This Skill Does

Guides Cowork through compliance tracking and audit preparation across major manufacturing regulatory frameworks, generating readiness checklists with gap analysis.

## Data Sources

Search ONLY the **Contoso Motors** SharePoint document library for compliance records and audit history. Do NOT search emails, Teams messages, or calendar.
- **SharePoint location**: `https://m365x38311559.sharepoint.com/sites/ContosoMotors/Shared Documents/Manufacturing Ops`
- Search for files matching: ISO 9001, audit readiness, compliance, CAPA, audit checklist
- Use existing audit documents and compliance records to inform the preparation

## Workflow

1. Search the Manufacturing Ops SharePoint library for existing compliance documents, audit checklists, and open CAPAs
2. Ask the user which standards apply to their operation and what type of audit is upcoming:
   - **Regulatory audit** (OSHA inspection, FDA inspection)
   - **Certification audit** (ISO 9001, IATF 16949 — registrar audit)
   - **Customer audit** (customer-specific requirements)
   - **Internal audit** (self-assessment)
2. Determine the applicable standard(s) and key clauses
3. Generate a readiness checklist with compliance status per clause
4. Identify gaps and create remediation action items
5. Prepare supporting materials (tour route, interview prep, document staging)

## Standards Coverage

### OSHA (29 CFR 1910 / 1926)
- Workplace safety program, written safety plans
- HazCom/GHS — SDS availability, labeling, training records
- Machine guarding — 29 CFR 1910.212, point-of-operation guards
- LOTO — 29 CFR 1910.147, energy control procedures, annual inspection
- Confined space — 29 CFR 1910.146, permits, rescue plan
- PPE — hazard assessment, training, inspection records
- Recordkeeping — OSHA 300 log, 300A posting, 301 incident reports

### ISO 9001:2015
Key clauses for manufacturing:
- **4. Context** — interested parties, scope, QMS processes
- **5. Leadership** — quality policy, roles/responsibilities
- **6. Planning** — risk-based thinking, quality objectives
- **7. Support** — competence, awareness, documented information, monitoring/measuring resources
- **8. Operation** — operational planning, requirements, design, external providers, production, release, nonconforming outputs
- **9. Performance evaluation** — monitoring, internal audit, management review
- **10. Improvement** — nonconformity/corrective action, continual improvement

### IATF 16949:2016 (Automotive)
Adds to ISO 9001:
- APQP (Advanced Product Quality Planning)
- PPAP (Production Part Approval Process)
- Control Plans — pre-launch and production
- MSA (Measurement System Analysis) — Gage R&R
- SPC (Statistical Process Control) — control charts, Cpk
- Customer-Specific Requirements (CSRs) per OEM

### FDA (21 CFR Part 820 — Medical Devices)
- Design controls and design history file (DHF)
- Device history records (DHR) and device master records (DMR)
- Complaint handling and MDR (Medical Device Reporting)
- CAPA (Corrective and Preventive Action)
- Validation — IQ/OQ/PQ (Installation/Operational/Performance Qualification)
- Supplier controls and purchasing

### GMP / cGMP (21 CFR Parts 210-211 — Pharma, or similar)
- Batch records and batch release
- Cleaning validation
- Environmental monitoring
- Personnel training and gowning
- Deviation management and investigation
- Stability programs

## Audit Readiness Checklist Output

| # | Standard | Clause/Section | Requirement | Status | Evidence Location | Gap Description | Remediation Action | Owner | Target Date |
|---|----------|----------------|-------------|--------|-------------------|-----------------|-------------------|-------|-------------|
| | | | | ✅ Compliant / ⚠️ Partial / ❌ Non-Compliant / ➖ Not Assessed | | | | | |

## Customer Audit Prep Checklist

- [ ] Customer-specific requirements (CSRs) reviewed
- [ ] Facility tour route planned (safety, clean, organized — 5S)
- [ ] Key documents pre-staged (quality manual, control plans, FMEAs, inspection records)
- [ ] Interview preparation — key personnel briefed on their areas
- [ ] Recent corrective actions / CAPAs closed and verified
- [ ] KPI dashboards current (OEE, FPY, scrap, PPM, on-time delivery)
- [ ] Calibration records current for all gauges/instruments
- [ ] Training records current for all operators on audit scope processes

## Compliance Metrics Dashboard

| Metric | Target | Current | Trend | RAG |
|--------|--------|---------|-------|-----|
| Open audit findings | 0 | [#] | ↑↓→ | |
| CAPA aging (avg days) | <30 | [#] | | |
| Training compliance % | 100% | [%] | | |
| Document review currency % | 100% | [%] | | |
| Calibration on-time % | 100% | [%] | | |
| Supplier scorecard avg | ≥80 | [#] | | |
