---
name: cowork-plugin-manager
description: Install, manage, and troubleshoot Cowork plugins using the M365 Agents Toolkit CLI (`atk`). Use whenever the user wants to install a plugin package, convert a Claude plugin to MOS3 format, authenticate with M365/Azure, upload or sideload an app package, uninstall a plugin, check prerequisites, list available templates, preview or publish a plugin, validate a manifest, manage environments, or perform any plugin lifecycle task involving the `atk` CLI. Also triggers for "sideload", "upload plugin", "package plugin", "deploy plugin", "provision plugin", "plugin not working", or any reference to Cowork plugin management.
---

# Cowork Plugin Manager

Manage the full lifecycle of Cowork plugins using the M365 Agents Toolkit CLI (`atk`) and the local `Convert-ClaudePluginToMOS3.ps1` conversion script.

## Prerequisites

The `atk` CLI must be installed globally:

```sh
npm install -g @microsoft/m365agentstoolkit-cli
```

Verify installation:

```sh
atk --version
```

Run the prerequisite checker to confirm the environment is ready:

```sh
atk doctor
```

## Authentication

Before installing or managing plugins, authenticate with M365 and/or Azure:

```powershell
# Log in to M365
atk auth login m365

# Log in to Azure (needed for provisioning/deploying)
atk auth login azure

# Check connected accounts
atk auth list

# Log out
atk auth logout m365
atk auth logout azure
```

## Plugin Lifecycle

### 1. Convert a Claude Plugin to MOS3 Format

The workspace contains `Convert-ClaudePluginToMOS3.ps1` at the plugins root. Use it to convert any Claude plugin directory into an MOS3 `.zip` package:

```powershell
.\Convert-ClaudePluginToMOS3.ps1 `
    -PluginPath <path-to-claude-plugin> `
    -OutputPath . `
    -PrivacyUrl <privacy-url> `
    -TermsOfUseUrl <terms-url> `
    -DetailedOutput
```

**Required parameters:**
- `-PluginPath` — path to the Claude plugin directory (must contain `.claude-plugin/plugin.json`)
- `-PrivacyUrl` — privacy policy URL (no Claude equivalent; must be supplied)
- `-TermsOfUseUrl` — terms of use URL (no Claude equivalent; must be supplied)

**Optional parameters:**
- `-OutputPath` — where to write the `.zip` (default: current directory)
- `-AppId` — override the auto-generated GUID
- `-WebsiteUrl` — override the developer website URL
- `-DefaultAuthType` — `Auto`, `None`, `OAuthPluginVault`, or `ApiKeyPluginVault`
- `-DetailedOutput` — show detailed conversion progress

The script:
1. Reads `plugin.json` and `.mcp.json` from the Claude plugin
2. Scans `skills/` for SKILL.md files
3. Generates a `manifest.json` conforming to the MOS3 schema
4. Packages icons, skills, and commands into a `.zip`

Output filename follows the pattern: `{plugin-name}-mos3-{version}.zip`

### 2. Install (Sideload) a Plugin

Upload a packaged `.zip` to M365:

```powershell
# Personal scope (default)
atk install --file-path <plugin-name>-mos3-<version>.zip

# Shared scope (org-wide)
atk install --file-path <plugin-name>-mos3-<version>.zip --scope Shared
```

For XML-based Outlook add-ins:

```powershell
atk install --xml-path manifest.xml
```

### 3. Validate a Plugin Package

Check the manifest against schema and validation rules before installing:

```powershell
# Validate manifest directly
atk validate --manifest-file ./appPackage/manifest.json

# Validate a packaged zip
atk validate --package-file <plugin-name>-mos3-<version>.zip

# Use validation rules
atk validate --manifest-file ./manifest.json --validate-method validation-rules
```

### 4. Package a Plugin Project

Build a plugin project into a distributable package:

```powershell
atk package --folder <project-root> --env <environment>
```

Key parameters:
- `--manifest-file` — app manifest path (default: `./appPackage/manifest.json`)
- `--output-folder` — output directory (default: `./appPackage/build`)
- `--env-file` — `.env` file for variable substitution

### 5. Provision Cloud Resources

Run the provision stage defined in `m365agents.yml`:

```powershell
# Remote environment
atk provision --env dev --folder <project-root>

# Local environment
atk provision --env local
```

### 6. Deploy

Run the deploy stage:

```powershell
atk deploy --env dev --folder <project-root>
```

### 7. Preview

Preview the app during development:

```powershell
# Local preview in Teams
atk preview --env local

# Remote preview in Outlook
atk preview --env dev --m365-host outlook

# Open in a specific browser
atk preview --env local --browser edge
```

### 8. Publish

Publish to the organization app catalog:

```powershell
atk publish --env dev --folder <project-root>
```

### 9. Update Manifest

Push manifest changes to Developer Portal:

```powershell
atk update --env dev --manifest-file ./appPackage/manifest.json
```

### 10. Uninstall a Plugin

Clean up installed resources:

```powershell
# By title ID
atk uninstall -i false --mode title-id --title-id U_xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx

# By manifest ID
atk uninstall -i false --mode manifest-id --manifest-id xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx

# By environment (in an ATK project)
atk uninstall -i false --mode env --env dev --folder ./myapp

# Interactive mode (guided prompts)
atk uninstall
```

The `--options` flag controls what gets cleaned up: `m365-app`, `app-registration`, `bot-framework-registration`.

## Environment Management

```powershell
# List environments
atk env list

# Add a new environment copied from dev
atk env add staging --env dev

# Reset environment file
atk env reset
```

## Get Launch Info

Retrieve launch URLs for an installed app:

```powershell
# By title ID
atk launchinfo --title-id U_xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx

# By manifest ID
atk launchinfo --manifest-id xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
```

## Collaboration

Grant another user access to manage the app:

```powershell
atk collaborator grant -i false --env dev --email colleague@example.com

# Check current permissions
atk collaborator status --env dev
```

## Upgrade Projects

Upgrade a project to work with the latest ATK version:

```powershell
atk upgrade
atk upgrade --force
```

## Discovery

List available templates and samples for creating new projects:

```powershell
atk list templates
atk list samples
```

Create a new project from a template:

```powershell
atk new -c declarative-agent -l typescript -n my-agent -i false
```

## MOS3 Package Structure

A valid MOS3 plugin package (`.zip`) contains:

```
plugin-name-mos3-1.0.0.zip
├── manifest.json       # MOS3 Unified App Manifest
├── color.png           # Color icon (192x192)
├── outline.png         # Outline icon (32x32)
└── skills/             # Skill directories
    └── skill-name/
        └── SKILL.md    # Skill definition with YAML frontmatter
```

The `manifest.json` follows the `vDevPreview` schema and includes:
- `agentSkills` — array of `{ folder: "./skills/<name>" }` references
- `agentConnectors` — array of MCP server configurations with auth

## Troubleshooting

| Symptom | Action |
|---------|--------|
| `atk` not found | `npm install -g @microsoft/m365agentstoolkit-cli` |
| Auth errors | `atk auth list` to check status; re-login with `atk auth login m365` |
| Install fails | Run `atk validate` on the package first; check manifest schema version |
| Plugin not appearing | Check scope (Personal vs Shared); use `atk launchinfo` to verify |
| Conversion script fails | Ensure `.claude-plugin/plugin.json` exists; supply `-PrivacyUrl` and `-TermsOfUseUrl` |
| Prerequisites missing | Run `atk doctor` to identify what's needed |

## Global CLI Options

All `atk` commands support:

| Flag | Description |
|------|-------------|
| `--interactive` / `-i` | Enable/disable interactive mode (default: true) |
| `--debug` | Print debug information |
| `--verbose` | Print diagnostic information |
| `--help` / `-h` | Show help for the command |
| `--version` / `-v` | Display CLI version |

When scripting or running non-interactively, always pass `-i false`.
